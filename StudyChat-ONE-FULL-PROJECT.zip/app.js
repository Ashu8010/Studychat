const tL=document.getElementById("tab-login");
const tR=document.getElementById("tab-register");
const fL=document.getElementById("login-form");
const fR=document.getElementById("register-form");
const m=document.getElementById("message");

function setMode(l){
 tL.classList.toggle("active",l);
 tR.classList.toggle("active",!l);
 fL.classList.toggle("active",l);
 fR.classList.toggle("active",!l);
 m.textContent="";
}
tL.onclick=()=>setMode(true);
tR.onclick=()=>setMode(false);
fL.onsubmit=e=>{e.preventDefault();m.textContent="Inloggen gelukt (demo)";};
fR.onsubmit=e=>{e.preventDefault();m.textContent="Registratie gelukt (demo)";setMode(true);};
